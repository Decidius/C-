const socket = io.connect("https://www.themechanics.tk/");

socket.on('userCount', userCount => {
        document.getElementById('connectionCount').innerHTML = userCount;
  })